@push('css')
<!-- Select 2 -->
<link href="{{ asset('assets/plugins/select2/css/select2.min.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}" rel="stylesheet" />
@endpush

@push('script')
<script src="{{ asset('assets/plugins/select2/js/select2.min.js') }}"></script>
@endpush
