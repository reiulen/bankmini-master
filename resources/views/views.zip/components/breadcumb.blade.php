<!-- /.col -->
<div class="col-sm-6">
    <ol class="breadcrumb float-sm-right">
        {{ $slot }}
    </ol>
</div>
<!-- /.col -->
