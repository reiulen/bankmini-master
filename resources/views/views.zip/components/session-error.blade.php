@error($name)
    <span class="text-danger" style="font-size:12px;">{{ $message }}</span>
@enderror
